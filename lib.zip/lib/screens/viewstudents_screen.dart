import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:new_app/screens/facultystudent_details_screen.dart';


class ViewStudentsScreen extends StatefulWidget {
  const ViewStudentsScreen({super.key});

  @override
  State<ViewStudentsScreen> createState() => _ViewStudentsScreenState();
}

class _ViewStudentsScreenState extends State<ViewStudentsScreen> {
  final TextEditingController _searchController = TextEditingController();
  String searchType = "Name"; // default search type
  List<QueryDocumentSnapshot> results = [];

  Future<void> _performSearch() async {
    String query = _searchController.text.trim();

    if (query.isEmpty) return;

    QuerySnapshot snapshot;

    if (searchType == "Name") {
      snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('role', isEqualTo: 'student')
          .where('name', isEqualTo: query)
          .get();
    } else if (searchType == "Register No") {
      snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('role', isEqualTo: 'student')
          .where('registerNo', isEqualTo: query)
          .get();
    } else {
      // Year search
      snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('role', isEqualTo: 'student')
          .where('year', isEqualTo: query)
          .get();
    }

    setState(() {
      results = snapshot.docs;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Search Students")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Dropdown + Search bar
            Row(
              children: [
                DropdownButton<String>(
                  value: searchType,
                  items: const [
                    DropdownMenuItem(value: "Name", child: Text("Name")),
                    DropdownMenuItem(value: "Register No", child: Text("Register No")),
                    DropdownMenuItem(value: "Year", child: Text("Year")),
                  ],
                  onChanged: (val) {
                    setState(() {
                      searchType = val!;
                    });
                  },
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: "Enter $searchType",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: _performSearch,
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Results
            Expanded(
              child: results.isEmpty
                  ? const Center(child: Text("No results"))
                  : ListView.builder(
                      itemCount: results.length,
                      itemBuilder: (context, index) {
                        var student = results[index];
                        return Card(
                          child: ListTile(
                            leading: const Icon(Icons.person),
                            title: Text(student['name'] ?? "No Name"),
                            subtitle: Text("Reg No: ${student['registerNo'] ?? ''}"),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => StudentDetailsScreen(
                                    studentId: student.id,
                                  ),
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
