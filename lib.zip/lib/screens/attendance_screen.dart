import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddAttendanceScreen extends StatefulWidget {
  final String semester;
  final String uid;
  const AddAttendanceScreen({super.key, required this.semester,required this.uid});

  @override
  State<AddAttendanceScreen> createState() => _AddAttendanceScreenState();
}

class _AddAttendanceScreenState extends State<AddAttendanceScreen> {
  final _formKey = GlobalKey<FormState>();
  final _subjectController = TextEditingController();
  final _totalController = TextEditingController();
  final _attendedController = TextEditingController();

  final _auth = FirebaseAuth.instance;

  Future<void> _saveAttendance() async {
  if (_formKey.currentState!.validate()) {
    final currentUid = _auth.currentUser!.uid;
    final subject = _subjectController.text.trim();

    // If faculty is logged in, you must pass the student's UID to this screen
    // For students, just use their own uid
    final targetStudentId = widget.uid.isNotEmpty ? widget.uid : currentUid;

    await FirebaseFirestore.instance
        .collection("students")
        .doc(targetStudentId)
        .collection("semesters")
        .doc(widget.semester)
        .collection("attendance")
        .doc(subject)
        .set({
      "subject": subject,
      "totalClasses": int.tryParse(_totalController.text.trim()) ?? 0,
      "attendedClasses": int.tryParse(_attendedController.text.trim()) ?? 0,
      "timestamp": FieldValue.serverTimestamp(),
    });

    _subjectController.clear();
    _totalController.clear();
    _attendedController.clear();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Attendance saved successfully")),
    );
  }
}


  @override
  Widget build(BuildContext context) {
    final uid = _auth.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: Text("Attendance - ${widget.semester}")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _subjectController,
                    decoration: const InputDecoration(labelText: "Subject"),
                    validator: (val) =>
                        val!.isEmpty ? "Enter subject name" : null,
                  ),
                  TextFormField(
                    controller: _totalController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: "Total Classes"),
                    validator: (val) =>
                        val!.isEmpty ? "Enter total classes" : null,
                  ),
                  TextFormField(
                    controller: _attendedController,
                    keyboardType: TextInputType.number,
                    decoration:
                        const InputDecoration(labelText: "Attended Classes"),
                    validator: (val) =>
                        val!.isEmpty ? "Enter attended classes" : null,
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _saveAttendance,
                    child: const Text("Save"),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Divider(),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection("students")
                    .doc(uid)
                    .collection("semesters")
                    .doc(widget.semester)
                    .collection("attendance")
                    .orderBy("timestamp", descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text("No attendance records yet"));
                  }
                  final docs = snapshot.data!.docs;
                  return ListView.builder(
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      final data = docs[index].data() as Map<String, dynamic>;
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        child: ListTile(
                          title: Text(data["subject"] ?? ""),
                          subtitle: Text(
                            "Attended: ${data["attendedClasses"]} / ${data["totalClasses"]}",
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
