import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:new_app/screens/student_home.dart';


class InternalMarksScreen extends StatefulWidget {
  final String semester;
  
  const InternalMarksScreen({super.key, required this.semester,});

  @override
  State<InternalMarksScreen> createState() => _InternalMarksScreenState();
}

class _InternalMarksScreenState extends State<InternalMarksScreen> {
  final _firestore = FirebaseFirestore.instance;
  final user = FirebaseAuth.instance.currentUser;

  String selectedExam = "Exam 1";
  final List<String> exams = ["Exam 1", "Exam 2", "Exam 3"];

  void _addCourse() async {
    if (user == null) return;

    final docRef = _firestore
        .collection("students")
        .doc(user!.uid)
        .collection("semesters")
        .doc(widget.semester)
        .collection("internalMarks")
        .doc(selectedExam)
        .collection("courses")
        .doc(); // auto ID

    await docRef.set({
      "courseCode": "",
      "courseName": "",
      "marks": 0,
      "saved": false, // NEW flag to track if saved
    });
  }

  Future<void> _saveCourse(
      String courseId, Map<String, dynamic> data) async {
    if (user == null) return;

    final docRef = _firestore
        .collection("students")
        .doc(user!.uid)
        .collection("semesters")
        .doc(widget.semester)
        .collection("internalMarks")
        .doc(selectedExam)
        .collection("courses")
        .doc(courseId);

    data["saved"] = true; // mark as saved
    await docRef.set(data, SetOptions(merge: true));
  }

  @override
  Widget build(BuildContext context) {
    final coursesRef = _firestore
        .collection("students")
        .doc(user!.uid)
        .collection("semesters")
        .doc(widget.semester)
        .collection("internalMarks")
        .doc(selectedExam)
        .collection("courses");

    return Scaffold(
      appBar: AppBar(
        title: Text("Internal Marks - ${widget.semester}"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
  if (Navigator.canPop(context)) {
    Navigator.pop(context);
  } else {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => StudentHomeScreen(), // fallback
      ),
    );
  }
},



        ),
      ),
      body: Column(
        children: [
          // Dropdown for Exam selection
          Padding(
            padding: const EdgeInsets.all(12),
            child: DropdownButtonFormField<String>(
              value: selectedExam,
              decoration: const InputDecoration(
                labelText: "Select Exam",
                border: OutlineInputBorder(),
              ),
              items: exams.map((exam) {
                return DropdownMenuItem(value: exam, child: Text(exam));
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedExam = value!;
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: coursesRef.snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                      child: Text("Error loading courses"));
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final courses = snapshot.data!.docs;

                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    ...courses.map((doc) {
                      final data = Map<String, dynamic>.from(doc.data() as Map);
                      final courseId = doc.id;
                      final isSaved = data["saved"] == true;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 16),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              TextField(
                                controller: TextEditingController(
                                    text: data["courseCode"] ?? ""),
                                decoration: const InputDecoration(
                                  labelText: "Course Code",
                                ),
                                enabled: !isSaved,
                                onChanged: (v) {
                                  if (!isSaved) data["courseCode"] = v;
                                },
                              ),
                              TextField(
                                controller: TextEditingController(
                                    text: data["courseName"] ?? ""),
                                decoration: const InputDecoration(
                                  labelText: "Course Name",
                                ),
                                enabled: !isSaved,
                                onChanged: (v) {
                                  if (!isSaved) data["courseName"] = v;
                                },
                              ),
                              TextField(
                                controller: TextEditingController(
                                    text: data["marks"]?.toString() ?? "0"),
                                decoration: const InputDecoration(
                                  labelText: "Marks",
                                ),
                                keyboardType: TextInputType.number,
                                enabled: !isSaved,
                                onChanged: (v) {
                                  if (!isSaved) {
                                    data["marks"] = int.tryParse(v) ?? 0;
                                  }
                                },
                              ),
                              const SizedBox(height: 10),
                              if (!isSaved)
                                ElevatedButton.icon(
                                  onPressed: () {
                                    _saveCourse(courseId, data);
                                  },
                                  icon: const Icon(Icons.save),
                                  label: const Text("Save"),
                                ),
                            ],
                          ),
                        ),
                      );
                    }),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: _addCourse,
                      icon: const Icon(Icons.add),
                      label: const Text("Add New Course"),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
