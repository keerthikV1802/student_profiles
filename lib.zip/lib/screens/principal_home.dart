import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PrincipalHome extends StatelessWidget {
  const PrincipalHome({super.key});

  @override
  Widget build(BuildContext context) {
    final _db = FirebaseFirestore.instance;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Principal Dashboard"),
        backgroundColor: Colors.blueGrey,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _db.collection("users").snapshots(), // access all users
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("No users found."));
          }

          final users = snapshot.data!.docs;

          return ListView.builder(
            itemCount: users.length,
            itemBuilder: (context, index) {
              final user = users[index].data() as Map<String, dynamic>;
              return Card(
                margin: const EdgeInsets.all(8),
                child: ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(user['name'] ?? 'No Name'),
                  subtitle: Text(
                    "Email: ${user['email'] ?? ''}\n"
                    "Role: ${user['role'] ?? ''} | Dept: ${user['dept'] ?? ''}",
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
