import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:new_app/screens/signup_screen.dart';
import '../services/auth_service.dart';
import 'student_home.dart';
import 'faculty_home.dart';
import 'admin_home.dart';
import 'principal_home.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _auth = AuthService();
  String email = "", password = "";
  bool _loading = false;
  String? _errorMessage;

  bool _obscurePassword = true; // 👁️ for password toggle

  Future<void> _handleLogin() async {
    setState(() {
      _loading = true;
      _errorMessage = null;
    });

    try {
      final user = await _auth.login(email, password);
      if (user != null) {
        final snap = await FirebaseFirestore.instance
            .collection("users")
            .doc(user.uid)
            .get();

        final data = snap.data();
        if (data != null) {
          switch (data["role"]) {
            case "student":
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const StudentHomeScreen()),
              );
              break;
            case "faculty":
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const FacultyDashboardScreen()),
              );
              break;
            case "admin":
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const AdminHome()),
              );
              break;
            case "principal":
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const PrincipalHome()),
              );
              break;
            default:
              setState(() => _errorMessage = "Unknown role detected.");
          }
        } else {
          setState(() => _errorMessage = "User data not found in Firestore.");
        }
      }
    } catch (e) {
      setState(() => _errorMessage = "Login failed: $e");
    }

    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              decoration: const InputDecoration(labelText: "Email"),
              onChanged: (v) => email = v,
            ),

            // 👁️ Password field with toggle
            TextField(
              obscureText: _obscurePassword,
              onChanged: (v) => password = v,
              decoration: InputDecoration(
                labelText: "Password",
                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off
                        : Icons.visibility,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                ),
              ),
            ),

            const SizedBox(height: 16),
            if (_errorMessage != null)
              Text(
                _errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ElevatedButton(
              onPressed: _loading ? null : _handleLogin,
              child: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Login"),
            ),
            const SizedBox(height: 16),

            // Only students can signup
            TextButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SignupScreen()),
              ),
              child: const Text("Don’t have an account? Sign up (Students only)"),
            ),
          ],
        ),
      ),
    );
  }
}
