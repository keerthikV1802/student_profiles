import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class StudentDetailsScreen extends StatefulWidget {
  final String studentId;
  const StudentDetailsScreen({super.key, required this.studentId});

  @override
  State<StudentDetailsScreen> createState() => _StudentDetailsScreenState();
}

class _StudentDetailsScreenState extends State<StudentDetailsScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();

  Future<void> _updatePersonalDetails() async {
    await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.studentId)
        .update({
      "name": _nameController.text,
      "email": _emailController.text,
      "phone": _phoneController.text,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Student Details")),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .doc(widget.studentId)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          var data = snapshot.data!.data() as Map<String, dynamic>;

          _nameController.text = data['name'] ?? '';
          _emailController.text = data['email'] ?? '';
          _phoneController.text = data['phone'] ?? '';

          return ListView(
            children: [
              // Personal Details
              ExpansionTile(
                leading: const Icon(Icons.person),
                title: const Text("Personal Details"),
                children: [
                  TextField(controller: _nameController, decoration: const InputDecoration(labelText: "Name")),
                  TextField(controller: _emailController, decoration: const InputDecoration(labelText: "Email")),
                  TextField(controller: _phoneController, decoration: const InputDecoration(labelText: "Phone")),
                  ElevatedButton(onPressed: _updatePersonalDetails, child: const Text("Save")),
                ],
              ),

              // TODO: Add Attendance ExpansionTile
              // TODO: Add Semester Marks ExpansionTile
              // TODO: Add Internal Marks ExpansionTile
              // TODO: Add Activities ExpansionTile
              // TODO: Add Upload Documents ExpansionTile
            ],
          );
        },
      ),
    );
  }
}
