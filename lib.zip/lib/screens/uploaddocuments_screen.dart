import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UploadDocumentScreen extends StatefulWidget {
  final String semesterName;

  const UploadDocumentScreen({super.key, required this.semesterName});

  @override
  State<UploadDocumentScreen> createState() => _UploadDocumentScreenState();
}

class _UploadDocumentScreenState extends State<UploadDocumentScreen> {
  final _titleController = TextEditingController();
  final _linkController = TextEditingController();
  final _descController = TextEditingController();

  Future<void> _uploadDoc() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    if (_titleController.text.isNotEmpty && _linkController.text.isNotEmpty) {
      await FirebaseFirestore.instance
          .collection('students')
          .doc(uid)
          .collection('semesters')
          .doc(widget.semesterName)
          .collection('uploadedDocs')
          .add({
        'title': _titleController.text,
        'link': _linkController.text,
        'description': _descController.text,
        'timestamp': FieldValue.serverTimestamp(),
      });

      _titleController.clear();
      _linkController.clear();
      _descController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(title: Text("Upload Docs - ${widget.semesterName}")),
      body: Column(
        children: [
          TextField(controller: _titleController, decoration: const InputDecoration(labelText: "Title")),
          TextField(controller: _linkController, decoration: const InputDecoration(labelText: "Document Link")),
          TextField(controller: _descController, decoration: const InputDecoration(labelText: "Description")),
          ElevatedButton(onPressed: _uploadDoc, child: const Text("Upload")),

          const Divider(),

          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('students')
                  .doc(uid)
                  .collection('semesters')
                  .doc(widget.semesterName)
                  .collection('uploadedDocs')
                  .orderBy('timestamp', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

                final docs = snapshot.data!.docs;
                if (docs.isEmpty) {
                  return const Center(child: Text("No documents uploaded yet."));
                }

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    return ListTile(
                      title: Text(doc['title']),
                      subtitle: Text(doc['description']),
                      trailing: IconButton(
                        icon: const Icon(Icons.open_in_new),
                        onPressed: () {
                          // TODO: Use url_launcher to open doc['link']
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
